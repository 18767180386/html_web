Project Description
-------
* Theme：ShareTravel is a shared sense of what one sees and hears tourism as the theme of the pure hand static page code.
* Technology：The structure of the code is clear, the style of the page is concise, Html, Div+Css, JavaScript, jQuery, XML.
* Support：If you have a problem or find an application error, you can submit a question here or contact me by mail. If you think this application is good, I hope you will give a "Star" to the project.

Contact Information
-------
* Author: 郭峰
* Email: iamguofeng@163.com 
* CSDN: http://blog.csdn.net/plain_maple

Application Screenshot
-------

<img src="https://github.com/iamguofeng/TourFootprint/raw/master/截图/首页 (1).jpg"  />
<img src="https://github.com/iamguofeng/TourFootprint/raw/master/截图/首页 (2).png"  />
<img src="https://github.com/iamguofeng/TourFootprint/raw/master/截图/景廊.png"  />
<img src="https://github.com/iamguofeng/TourFootprint/raw/master/截图/感悟.png"  />
<img src="https://github.com/iamguofeng/TourFootprint/raw/master/截图/注册.png"  />
